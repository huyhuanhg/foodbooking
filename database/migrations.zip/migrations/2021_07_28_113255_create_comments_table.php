<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCommentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comments', function (Blueprint $table) {
            $table->charset = 'utf8';
            $table->collation = 'utf8_general_ci';
            $table->increments("comment_id");
            $table->unsignedInteger("food_id");
            $table->unsignedInteger("user_id");
            $table->unsignedInteger("manager_id");
            $table->timestamp("create_at");
            $table->text("content");
            $table->foreign('food_id')->references('food_id')->on('foods');
            $table->foreign('user_id')->references('user_id')->on('users');
            $table->foreign('manager_id')->references('manager_id')->on('managers');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comments');
    }
}
