<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePersonsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('persons', function (Blueprint $table) {
            $table->increments('person_id');
            $table->string('first_name', 20);
            $table->string('last_name', 20);
            $table->string('phone')->unique()->nullable();
            $table->string("address", 300)->nullable();
            $table->tinyInteger('gender')->nullable();
            $table->date("birthday")->nullable();
            $table->string("avatar", 50)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('persons');
    }
}
